/**
 * Created by mattua on 23/07/2016.
 */
public class Credentials {


    public static final String access_key_id= "AKIAJQBA6TTUVSE7ROHA";

    public static final String secret_access_key ="<>";



}

