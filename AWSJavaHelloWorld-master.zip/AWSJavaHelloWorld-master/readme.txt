1. Generate the SDK for IOS



